import { Module } from '@nestjs/common';
import { InstitutionModule } from './institution/institution.module';
import { MongooseModule } from '@nestjs/mongoose';
import { InstitutionTypeModule } from './institution-type/institution-type.module';
import * as dotenv from 'dotenv';

dotenv.config();
@Module({
  imports: [InstitutionModule, MongooseModule.forRoot('mongodb://127.0.0.1:27017/backend'), InstitutionTypeModule],
  controllers: [],
  providers: [],
})
export class AppModule {}
